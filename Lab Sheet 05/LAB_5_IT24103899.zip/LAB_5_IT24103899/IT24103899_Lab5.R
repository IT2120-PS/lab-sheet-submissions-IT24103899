
setwd("/Users/bharanamihijaya/Downloads/Lab\ 05-20250828")  # CHANGE THIS TO YOUR PATH


getwd()


list.files()

# -------------------------------------------------------------------------

# -------------------------------------------------------------------------

# Step 2: Read the shareholder data
data_shareholders <- read.table("Data.txt", header = TRUE, sep = ",")

# View the data (optional)
print(data_shareholders)

# Extract the Number_of_Shareholders column
shareholders <- data_shareholders$Number_of_Shareholders.thousands.

# Add meaningful name
names(shareholders) <- data_shareholders$Company

# 1. Draw a histogram (default)
hist(shareholders,
     main = "Histogram of Number of Shareholders",
     xlab = "Number of Shareholders (thousands)",
     ylab = "Frequency",
     col = "lightblue",
     border = "black")

# 2. Histogram with 7 classes, lower limit = 130, upper limit = 270
# Define breaks: 7 classes from 130 to 270
breaks_7 <- seq(130, 270, length.out = 8)  # 8 points = 7 intervals

# Plot histogram with specified classes
hist(shareholders,
     breaks = breaks_7,
     main = "Histogram with 7 Classes (130 to 270)",
     xlab = "Number of Shareholders (thousands)",
     ylab = "Frequency",
     col = "skyblue2",
     border = "black",
     right = FALSE)  # Left-closed, right-open intervals

# 3. Construct frequency distribution table
# Use cut() to group data into 7 classes
groups <- cut(shareholders, breaks = breaks_7, right = FALSE, labels = FALSE)

# Build frequency table
freq_table <- table(groups)
cum_freq <- cumsum(freq_table)

# Create class midpoints
class_midpoints <- (breaks_7[-1] + breaks_7[-8]) / 2  # average of lower and upper

# Make a clean frequency distribution table
freq_dist <- data.frame(
  "Class Interval" = paste(breaks_7[-8], "-", breaks_7[-1]),
  "Frequency" = as.vector(freq_table),
  "Cumulative Frequency" = cum_freq,
  "Midpoint" = class_midpoints
)

# Print and save frequency distribution
print(freq_dist)
write.csv(freq_dist, "Shareholders_Frequency_Distribution.csv", row.names = FALSE)

# 4. Frequency Polygon
plot(class_midpoints, as.vector(freq_table),
     type = "o",
     col = "red",
     lwd = 2,
     xlab = "Number of Shareholders (midpoints)",
     ylab = "Frequency",
     main = "Frequency Polygon of Shareholders")

# Add lines connecting points
lines(class_midpoints, as.vector(freq_table), type = "o", col = "red", lwd = 2)

# 5. Cumulative Frequency Polygon (Ogive)
plot(class_midpoints, cum_freq,
     type = "o",
     col = "blue",
     lwd = 2,
     xlab = "Number of Shareholders (midpoints)",
     ylab = "Cumulative Frequency",
     main = "Ogive (Cumulative Frequency Polygon)")

# Connect points
lines(class_midpoints, cum_freq, type = "o", col = "blue", lwd = 2)

# -------------------------------------------------------------------------
# PART B: DELIVERY TIMES DATA (Exercise - Lab 05.txt)
# Tasks: Import, histogram (9 intervals), shape, ogive
# -------------------------------------------------------------------------

# Step: Read delivery times data (single column)
delivery_times <- read.table("Exercise - Lab 05.txt", header = TRUE)

# Store in a data frame called "DeliveryTimes" (as per instruction)
DeliveryTimes <- data.frame(delivery_times)
names(DeliveryTimes) <- "Delivery_Time_minutes"  # Rename column

# Extract vector for ease
times <- DeliveryTimes$Delivery_Time_minutes

# 1. Histogram with 9 class intervals, lower=20, upper=70, right-open
breaks_9 <- seq(20, 70, length.out = 10)  # 10 points = 9 intervals

hist(times,
     breaks = breaks_9,
     right = FALSE,  # Left-closed, right-open intervals
     main = "Histogram of Delivery Times (9 Classes)",
     xlab = "Delivery Time (minutes)",
     ylab = "Frequency",
     col = "orange",
     border = "darkgray")

# 2. Comment on the shape
# After viewing the histogram, typical comment:
# "The distribution of delivery times is approximately symmetric / slightly right-skewed."
# You can add skewness check:

# Optional: Calculate skewness (install if needed)
if (!require("moments")) install.packages("moments")
library(moments)
skew <- skewness(times)
cat("Skewness of delivery times:", round(skew, 3), "\n")
# If positive: right-skewed; near 0: symmetric; negative: left-skewed

# 3. Cumulative Frequency Polygon (Ogive) for delivery times
# Group data into 9 classes
groups_times <- cut(times, breaks = breaks_9, right = FALSE, labels = FALSE)
freq_times <- table(groups_times)
cum_freq_times <- cumsum(freq_times)
midpoints_times <- (breaks_9[-1] + breaks_9[-10]) / 2  # 9 midpoints

# Plot ogive
plot(midpoints_times, cum_freq_times,
     type = "o",
     col = "green",
     lwd = 2,
     xlab = "Delivery Time (minutes)",
     ylab = "Cumulative Frequency",
     main = "Ogive: Cumulative Frequency of Delivery Times")

lines(midpoints_times, cum_freq_times, type = "o", col = "green", lwd = 2)

# -------------------------------------------------------------------------
# Final Step: Save workspace (optional)
# Save all objects
save.image("Lab05_Workspace.RData")

# End of script